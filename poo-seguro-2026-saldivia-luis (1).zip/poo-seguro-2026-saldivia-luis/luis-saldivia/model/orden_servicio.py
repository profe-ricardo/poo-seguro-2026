from repository import repositorio

from .cliente import Cliente
from .equipo import Equipo

ESTADOS_VALIDOS = (
    "Recibido",
    "En diagnostico",
    "En reparacion",
    "Listo",
    "Entregado",
)


class OrdenServicio:
    def __init__(
        self,
        descripcion: str,
        cliente: Cliente,
        equipo: Equipo,
        estado: str = "Recibido",
        diagnostico: str = "",
    ):
        if estado not in ESTADOS_VALIDOS:
            raise ValueError(f"Estado invalido. Opciones: {ESTADOS_VALIDOS}")

        self.numero = None  # lo genera la BD al guardar
        self.descripcion = descripcion
        self.estado = estado
        self.diagnostico = diagnostico
        self.cliente = cliente
        self.equipo = equipo

    def validar_tabla(self):
        """Crea la tabla ordenes_servicio (y sus dependencias) si no existen."""
        return repositorio.validar_tabla("clientes", "equipos", "ordenes_servicio")

    def guardar(self):
        """Valida la tabla y guarda la orden. Retorna el numero (o None si falla).

        Si el cliente o el equipo aun no estan en la BD, los guarda primero.
        """
        if not self.validar_tabla():
            return None
        if self.cliente.id is None and self.cliente.guardar() is None:
            return None
        if self.equipo.id is None and self.equipo.guardar() is None:
            return None
        return repositorio.guardar_orden(self)

    def cambiar_estado(self, nuevo_estado: str):
        """Cambia el estado y lo registra en la BD (si la orden ya fue guardada)."""
        if nuevo_estado not in ESTADOS_VALIDOS:
            raise ValueError(f"Estado invalido. Opciones: {ESTADOS_VALIDOS}")

        anterior = self.estado
        self.estado = nuevo_estado

        if self.numero is not None and not repositorio.actualizar_orden(self):
            self.estado = anterior  # no se pudo registrar: se mantiene el estado previo

    def registrar_diagnostico(self, diagnostico: str):
        """Registra el diagnostico y lo guarda en la BD (si la orden ya fue guardada)."""
        if not isinstance(diagnostico, str):
            raise ValueError("El diagnostico debe ser de tipo str")

        anterior = self.diagnostico
        self.diagnostico = diagnostico

        if self.numero is not None and not repositorio.actualizar_orden(self):
            self.diagnostico = anterior

    def mostrar_resumen(self):
        return (
            f"Orden de Servicio\n Numero: {self.numero} | "
            f"Cliente: {self.cliente.nombre} | "
            f"Equipo: {self.equipo.tipo} {self.equipo.marca} | "
            f"Estado: {self.estado} | Diagnostico: {self.diagnostico or '-'}"
        )
