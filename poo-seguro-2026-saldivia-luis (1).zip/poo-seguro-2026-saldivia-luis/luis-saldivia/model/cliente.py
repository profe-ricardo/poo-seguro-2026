from repository import repositorio


class Cliente:
    def __init__(self, nombre: str, telefono: str, correo: str):
        self.id = None  # se asigna al guardar en la BD
        self.nombre = nombre
        self.telefono = telefono
        self.correo = correo

    def validar_tabla(self):
        return repositorio.validar_tabla("clientes")

    def guardar(self):
        """Valida la tabla y guarda el cliente. Retorna el id (o None si falla)."""
        if not self.validar_tabla():
            return None
        return repositorio.guardar_cliente(self)

    def mostrar_datos(self):
        return (
            f"Persona\n Nombre: {self.nombre} | "
            f"Telefono: {self.telefono} | Correo: {self.correo}"
        )

    def actualizar_telefono(self, nuevo_telefono: str):
        if not isinstance(nuevo_telefono, str):
            raise ValueError("El telefono debe ser de tipo str")

        anterior = self.telefono
        self.telefono = nuevo_telefono

        # Si el cliente ya esta en la BD, se actualiza tambien alli
        if self.id is not None and not repositorio.actualizar_telefono_cliente(self):
            self.telefono = anterior
