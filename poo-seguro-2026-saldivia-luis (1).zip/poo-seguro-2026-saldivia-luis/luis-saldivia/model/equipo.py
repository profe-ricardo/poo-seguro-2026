from repository import repositorio


class Equipo:
    def __init__(self, tipo: str, marca: str, modelo: str, serie: str):
        self.id = None  # se asigna al guardar en la BD
        self.tipo = tipo
        self.marca = marca
        self.modelo = modelo
        self.serie = serie

    def validar_tabla(self):
        """Crea la tabla equipos si no existe."""
        return repositorio.validar_tabla("equipos")

    def guardar(self):
        """Valida la tabla y guarda el equipo. Retorna el id (o None si falla)."""
        if not self.validar_tabla():
            return None
        return repositorio.guardar_equipo(self)

    def mostrar_datos(self):
        return (
            f"Equipo\n Tipo: {self.tipo} | Marca: {self.marca} | "
            f"Modelo: {self.modelo} | Serie: {self.serie}"
        )
