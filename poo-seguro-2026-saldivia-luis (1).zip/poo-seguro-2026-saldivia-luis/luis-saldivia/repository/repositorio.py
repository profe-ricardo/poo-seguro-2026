import oracledb

from config.app_config import conectar_db

ORA_YA_EXISTE_OBJETO = 955  # ORA-00955: el nombre ya esta en uso
ORA_DUPLICADO = 1  # ORA-00001: viola restriccion unica

TABLAS = {
    "clientes": """
        create table clientes (
            id number generated always as identity primary key,
            nombre varchar2(100) not null,
            telefono varchar2(30),
            correo varchar2(100),
            constraint uq_cliente unique (nombre, telefono, correo)
        )
    """,
    "equipos": """
        create table equipos (
            id number generated always as identity primary key,
            tipo varchar2(50),
            marca varchar2(50),
            modelo varchar2(50),
            serie varchar2(100) not null,
            constraint uq_equipo_serie unique (serie)
        )
    """,
    "ordenes_servicio": """
        create table ordenes_servicio (
            numero number generated always as identity primary key,
            descripcion varchar2(500),
            estado varchar2(30) not null,
            diagnostico varchar2(500),
            cliente_id number not null,
            equipo_id number not null,
            constraint fk_orden_cliente foreign key (cliente_id) references clientes (id),
            constraint fk_orden_equipo foreign key (equipo_id) references equipos (id)
        )
    """,
}


def validar_tabla(*nombres):
    """Crea las tablas indicadas si no existen (compatible con Oracle < 23ai).

    Sin argumentos valida todas, en orden (respeta las claves foraneas).
    """
    conn = conectar_db()
    if not conn:
        return False

    try:
        with conn.cursor() as cursor:
            for nombre in nombres or TABLAS:
                try:
                    cursor.execute(TABLAS[nombre])
                    print(f"[INFO] Tabla {nombre} creada")
                except oracledb.DatabaseError as e:
                    if e.args[0].code != ORA_YA_EXISTE_OBJETO:
                        raise
        return True
    except oracledb.Error as e:
        print(f"[ERROR] Validacion de tablas | {e}")
        return False
    finally:
        conn.close()


def crear_tablas():
    return validar_tabla()


def _guardar_con_id_existente(insert_sql, params, select_sql, select_params):
    """Inserta y devuelve el id. Si ya existe (ORA-00001), devuelve el id existente."""
    conn = conectar_db()
    if not conn:
        return None

    try:
        with conn.cursor() as cursor:
            id_var = cursor.var(int)
            try:
                cursor.execute(insert_sql + " returning id into :id_out", [*params, id_var])
                conn.commit()
                return id_var.getvalue()[0]
            except oracledb.IntegrityError as e:
                conn.rollback()
                if e.args[0].code != ORA_DUPLICADO:
                    raise
                print("[WARNING] Registro ya existente, se reutiliza")
                cursor.execute(select_sql, select_params)
                fila = cursor.fetchone()
                return fila[0] if fila else None
    except oracledb.Error as e:
        conn.rollback()
        print(f"[ERROR] No se pudo guardar | {e}")
        return None
    finally:
        conn.close()


def guardar_cliente(cliente):
    cliente.id = _guardar_con_id_existente(
        "insert into clientes (nombre, telefono, correo) values (:1, :2, :3)",
        [cliente.nombre, cliente.telefono, cliente.correo],
        "select id from clientes where nombre = :1 and telefono = :2 and correo = :3",
        [cliente.nombre, cliente.telefono, cliente.correo],
    )
    return cliente.id


def actualizar_telefono_cliente(cliente):
    """Persiste el telefono actual del objeto (requiere cliente.id)."""
    if cliente.id is None:
        print("[ERROR] El cliente aun no esta guardado en la BD")
        return False

    conn = conectar_db()
    if not conn:
        return False

    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "update clientes set telefono = :1 where id = :2",
                [cliente.telefono, cliente.id],
            )
            conn.commit()
            return True
    except oracledb.Error as e:
        conn.rollback()
        print(f"[ERROR] No se pudo actualizar telefono | {e}")
        return False
    finally:
        conn.close()


def guardar_equipo(equipo):
    equipo.id = _guardar_con_id_existente(
        "insert into equipos (tipo, marca, modelo, serie) values (:1, :2, :3, :4)",
        [equipo.tipo, equipo.marca, equipo.modelo, equipo.serie],
        "select id from equipos where serie = :1",
        [equipo.serie],
    )
    return equipo.id


def guardar_orden(orden):
    if orden.cliente.id is None or orden.equipo.id is None:
        print("[ERROR] Guarda primero el cliente y el equipo")
        return None

    conn = conectar_db()
    if not conn:
        return None

    try:
        with conn.cursor() as cursor:
            numero_var = cursor.var(int)
            cursor.execute(
                """
                insert into ordenes_servicio
                    (descripcion, estado, diagnostico, cliente_id, equipo_id)
                values (:1, :2, :3, :4, :5)
                returning numero into :numero_out
                """,
                [
                    orden.descripcion,
                    orden.estado,
                    orden.diagnostico,
                    orden.cliente.id,
                    orden.equipo.id,
                    numero_var,
                ],
            )
            conn.commit()
            orden.numero = numero_var.getvalue()[0]
            return orden.numero
    except oracledb.Error as e:
        conn.rollback()
        print(f"[ERROR] No se pudo guardar la orden | {e}")
        return None
    finally:
        conn.close()


def actualizar_orden(orden):
    """Persiste estado y diagnostico actuales (requiere orden.numero)."""
    if orden.numero is None:
        print("[ERROR] La orden aun no esta guardada en la BD")
        return False

    conn = conectar_db()
    if not conn:
        return False

    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "update ordenes_servicio set estado = :1, diagnostico = :2 where numero = :3",
                [orden.estado, orden.diagnostico, orden.numero],
            )
            conn.commit()
            return True
    except oracledb.Error as e:
        conn.rollback()
        print(f"[ERROR] No se pudo actualizar la orden | {e}")
        return False
    finally:
        conn.close()
