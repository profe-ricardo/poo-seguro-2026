"""
    Reglas PEP8:
    - clases -> inicial en mayúscula, palabra en minúscula
    - funciones -> todo en minúscula y en snake_case
"""

from model.cliente import Cliente
from model.equipo import Equipo
from model.orden_servicio import OrdenServicio


def main():
    print("---")
    persona_1 = Cliente("Pedro", "912345678", "pedro@hola.com")
    persona_1.guardar()
    print(persona_1.mostrar_datos())
    persona_1.actualizar_telefono("987654321")

    equipo_1 = Equipo("Telefono", "Xiaomi", "Redmi 14c", "123456")
    equipo_1.guardar()
    print(equipo_1.mostrar_datos())

    orden_servicio_1 = OrdenServicio("Equipo no prende", persona_1, equipo_1)
    orden_servicio_1.guardar()
    print(orden_servicio_1.mostrar_resumen())

    orden_servicio_1.registrar_diagnostico("Bateria danada")
    orden_servicio_1.cambiar_estado("En reparacion")
    print(orden_servicio_1.mostrar_resumen())


if __name__ == "__main__":
    main()
