import os

import oracledb
from dotenv import load_dotenv

load_dotenv()

DB_DSN = os.getenv("DB_DSN")
DB_PASS = os.getenv("DB_PASS")
DB_USER = os.getenv("DB_USER")


def conectar_db():
    """Conexión a BD Oracle. Retorna None si falla."""
    if not all([DB_DSN, DB_USER, DB_PASS]):
        print("[ERROR] Faltan DB_DSN, DB_USER o DB_PASS en el archivo .env")
        return None

    try:
        return oracledb.connect(user=DB_USER, password=DB_PASS, dsn=DB_DSN)
    except oracledb.Error as e:
        print(f"[ERROR] No se pudo conectar a BD | {e}")
        return None
